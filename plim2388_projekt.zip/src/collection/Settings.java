package collection;

public class Settings {
    public static Integer ORIGINAL_SPEED;
    public static Integer SPEED;
    public static Integer WIDTH;
    public static Integer HEIGHT;
    public static Boolean IS_RUNNING;
    public static Direction DIRECTION;
    public static Integer MUSIC_VOLUME;
    public static Integer SOUND_VOLUME;
    public static Integer HIGH_SCORE;
}
