package exceptions;

public class NoPanelException extends Exception {
}
