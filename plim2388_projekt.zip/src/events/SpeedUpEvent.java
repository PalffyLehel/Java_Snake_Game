package events;

import java.util.EventObject;

public class SpeedUpEvent extends EventObject {
    public SpeedUpEvent(Object source) {
        super(source);
    }
}
