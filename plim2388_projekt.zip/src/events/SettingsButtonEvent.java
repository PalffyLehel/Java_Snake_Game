package events;

import java.util.EventObject;

public class SettingsButtonEvent extends EventObject {
    public SettingsButtonEvent(Object source) {
        super(source);
    }
}
