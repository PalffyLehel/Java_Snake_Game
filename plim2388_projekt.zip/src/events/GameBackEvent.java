package events;

import java.util.EventObject;

public class GameBackEvent extends EventObject {
    public GameBackEvent(Object source) {
        super(source);
    }
}
